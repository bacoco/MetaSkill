#!/bin/bash
# NEXUS Installation Script
echo "Installing NEXUS..."
echo "NEXUS installation completed!"
echo "Claude will automatically use NEXUS when appropriate."
