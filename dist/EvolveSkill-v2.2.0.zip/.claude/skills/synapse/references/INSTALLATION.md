# Synapse Installation Guide

Complete setup instructions for Synapse automatic skill generation.

## Prerequisites

- Python 3.7 or higher
- Cortex skill installed
- Git repository (for automatic monitoring)

## Quick Install

```bash
# 1. Synapse is already installed if you have .claude/skills/synapse/
cd /path/to/your/project

# 2. Verify Synapse is present
ls -la .claude/skills/synapse/

# 3. Test Synapse
python .claude/skills/synapse/scripts/synapse_analyzer.py --dry-run
```

That's it! Synapse is ready to use.

## Automatic Monitoring Setup

For automatic skill generation, set up monitoring via cron or git hooks.

### Option 1: Cron Job (Recommended)

Automatically run Synapse every 30 minutes:

```bash
# Edit crontab
crontab -e

# Add this line for every 30 minutes
*/30 * * * * /path/to/.claude/skills/synapse/scripts/synapse_auto_watch.sh >> /path/to/.synapse_cron.log 2>&1

# Or for hourly monitoring
0 * * * * /path/to/.claude/skills/synapse/scripts/synapse_auto_watch.sh >> /path/to/.synapse_cron.log 2>&1
```

**Adjust path:**

```bash
# Get absolute path
PROJECT_DIR=$(pwd)
echo "*/30 * * * * $PROJECT_DIR/.claude/skills/synapse/scripts/synapse_auto_watch.sh >> $PROJECT_DIR/.synapse_cron.log 2>&1" | crontab -
```

**Verify cron:**

```bash
# Check cron is scheduled
crontab -l

# Check logs after 30 minutes
tail -f .synapse_cron.log
```

### Option 2: Git Hook

Run Synapse automatically after every commit:

```bash
# Create post-commit hook
cat > .git/hooks/post-commit << 'EOF'
#!/bin/bash
# Run Synapse in background after commits

PROJECT_DIR=$(git rev-parse --show-toplevel)
"$PROJECT_DIR/.claude/skills/synapse/scripts/synapse_auto_watch.sh" >> "$PROJECT_DIR/.synapse_git_hook.log" 2>&1 &
EOF

# Make executable
chmod +x .git/hooks/post-commit
```

**Test git hook:**

```bash
# Make a test commit
echo "test" >> .gitignore
git add .gitignore
git commit -m "test: Synapse git hook"

# Check hook ran
tail .synapse_git_hook.log
```

### Option 3: Manual Runs

Run Synapse manually whenever needed:

```bash
# Analyze and auto-generate
python .claude/skills/synapse/scripts/auto_skill_generator.py

# Analyze only (no generation)
python .claude/skills/synapse/scripts/synapse_analyzer.py
```

## Configuration Setup

### Basic Configuration

Create `.synapse_config.json`:

```bash
cat > .synapse_config.json << 'EOF'
{
  "analysis": {
    "threshold": 5,
    "window_days": 7,
    "auto_threshold": "high"
  },
  "sources": {
    "cortex_memory": true,
    "prd_files": true,
    "task_lists": true
  },
  "auto_generation": {
    "enabled": true,
    "max_skills_per_run": 5,
    "log_to_cortex": true
  },
  "logging": {
    "enabled": true,
    "file": ".synapse_auto.log",
    "level": "INFO"
  }
}
EOF
```

### Project-Specific Paths

For non-standard project structures:

```json
{
  "paths": {
    "skills_dir": ".claude/skills",
    "prd_patterns": ["docs/*PRD*.md", "requirements/*.md"],
    "todo_patterns": ["tasks/*.md", "TODO.md"]
  }
}
```

## Verification

### Test Synapse Installation

```bash
# 1. Check Synapse files exist
ls -la .claude/skills/synapse/scripts/

# Expected output:
# synapse_analyzer.py
# auto_skill_generator.py
# cortex_integration.py

# 2. Test analyzer
python .claude/skills/synapse/scripts/synapse_analyzer.py --dry-run

# Expected output:
# 📊 Synapse Unified Analyzer
# ✅ Analysis complete

# 3. Test auto-generator
python .claude/skills/synapse/scripts/auto_skill_generator.py --dry-run

# Expected output:
# 🤖 Synapse Auto Skill Generator (DRY RUN)
# 📊 Analysis Results: ...
```

### Test Cortex Integration

```bash
# 1. Check Cortex is available
python -c "from cortex_api import get_cortex_memory; print('✅ Cortex API available')"

# 2. Add test event
python -c "from cortex_api import add_cortex_event; add_cortex_event('test', 'Synapse test event')"

# 3. Run Synapse to detect
python .claude/skills/synapse/scripts/synapse_analyzer.py
```

### Test Automatic Monitoring

If using cron:

```bash
# Wait 30 minutes, then check logs
tail -f .synapse_cron.log
```

If using git hook:

```bash
# Make a test commit
git commit --allow-empty -m "test: Synapse monitoring"

# Check log
tail .synapse_git_hook.log
```

## Troubleshooting Installation

### Cortex Not Found

**Error:**
```
ModuleNotFoundError: No module named 'cortex_api'
```

**Solution:**

```bash
# Check Cortex is installed
ls -la .claude/skills/cortex/scripts/cortex_api.py

# Install Cortex if missing
cd .claude/skills/cortex/scripts
./install.sh
```

### Permission Denied

**Error:**
```
Permission denied: .synapse_auto.log
```

**Solution:**

```bash
# Create log file with correct permissions
touch .synapse_auto.log
chmod 644 .synapse_auto.log

# For cron, ensure directory is writable
chmod 755 $(pwd)
```

### Cron Not Running

**Error:**
Cron job not executing

**Solution:**

```bash
# Check cron service is running
systemctl status cron   # Linux
sudo launchctl list | grep cron  # macOS

# Check cron logs
grep Synapse /var/log/syslog  # Linux
grep Synapse /var/log/system.log  # macOS

# Use absolute paths in crontab
crontab -e
# Change: */30 * * * * ./script.sh
# To: */30 * * * * /full/path/to/script.sh
```

### Git Hook Not Triggering

**Error:**
Hook exists but doesn't run

**Solution:**

```bash
# Check hook is executable
ls -la .git/hooks/post-commit
# Should show: -rwxr-xr-x

# Make executable if needed
chmod +x .git/hooks/post-commit

# Test hook manually
.git/hooks/post-commit

# Check for errors
cat .synapse_git_hook.log
```

## Uninstallation

### Remove Cron Job

```bash
# Edit crontab
crontab -e

# Remove Synapse line, save and exit

# Verify removal
crontab -l | grep synapse
# Should show nothing
```

### Remove Git Hook

```bash
rm .git/hooks/post-commit
```

### Remove Configuration

```bash
rm .synapse_config.json
rm .synapse_auto.log
rm .synapse_cron.log
rm .synapse_git_hook.log
```

### Keep Synapse, Disable Auto-Generation

```json
{
  "auto_generation": {
    "enabled": false
  }
}
```

Or remove cron/hooks but keep Synapse for manual use.

## Upgrading Synapse

If Synapse is updated:

```bash
# Pull latest version
git pull

# No additional steps needed - Python scripts auto-reload

# Test new version
python .claude/skills/synapse/scripts/auto_skill_generator.py --version
```

## Multi-Project Setup

### Shared Synapse Installation

For multiple projects sharing skills:

```bash
# Project structure
~/workspace/
├── .shared_skills/
│   └── synapse/
└── project1/
    └── .claude/
        └── skills/ -> ../../.shared_skills/
```

### Per-Project Synapse

Each project has its own Synapse:

```bash
~/workspace/
├── project1/
│   └── .claude/skills/synapse/
└── project2/
    └── .claude/skills/synapse/
```

Setup cron for each:

```bash
# Edit crontab
crontab -e

# Add line for each project
*/30 * * * * /home/user/workspace/project1/.claude/skills/synapse/scripts/synapse_auto_watch.sh
*/30 * * * * /home/user/workspace/project2/.claude/skills/synapse/scripts/synapse_auto_watch.sh
```

## Platform-Specific Notes

### Linux

- Cron service usually pre-installed
- Use `systemctl` to manage services
- Logs typically in `/var/log/syslog`

### macOS

- Use `cron` or `launchd` for scheduling
- `launchd` is preferred for system services
- Logs in `/var/log/system.log`

### Windows (WSL)

- Install cron: `sudo apt-get install cron`
- Start cron: `sudo service cron start`
- Use Linux instructions

### Windows (Native)

Use Task Scheduler instead of cron:

```powershell
# Create scheduled task
$action = New-ScheduledTaskAction -Execute "python" -Argument "C:\path\to\auto_skill_generator.py"
$trigger = New-ScheduledTaskTrigger -Once -At 12:00 -RepetitionInterval (New-TimeSpan -Minutes 30) -RepetitionDuration (New-TimeSpan -Days 365)
Register-ScheduledTask -TaskName "Synapse Monitor" -Action $action -Trigger $trigger
```

## Docker Setup

For containerized environments:

```dockerfile
# Dockerfile
FROM python:3.9

WORKDIR /app
COPY .claude/skills/synapse /app/.claude/skills/synapse

# Install cron
RUN apt-get update && apt-get install -y cron

# Add cron job
RUN echo "*/30 * * * * python /app/.claude/skills/synapse/scripts/auto_skill_generator.py" | crontab -

# Run cron in foreground
CMD ["cron", "-f"]
```

## See Also

- [MANUAL_USAGE.md](MANUAL_USAGE.md) - Command-line options
- [CONFIGURATION.md](CONFIGURATION.md) - Config reference
- [EXAMPLES.md](EXAMPLES.md) - Real-world examples
- Main SKILL.md - Synapse overview
